<?php

$pdo = new PDO('mysql:host=localhost;dbname=bd_teste', 'root', '');
echo 'ffffffffff';
